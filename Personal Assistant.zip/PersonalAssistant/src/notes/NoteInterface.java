
package notes;

public interface NoteInterface {
    public abstract void tableData();
    public abstract void delete();
    public abstract void edit();
    
}
