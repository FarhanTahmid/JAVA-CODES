
package user;

public class Universal {
    public static String user;
    public static String username;
    public static boolean confirm=false;
    public static String topic;
}
